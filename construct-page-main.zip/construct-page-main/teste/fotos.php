<?php
require_once 'AuthUser.php';
$p = new Imagem("dbsarah", "localhost", "root", "");
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro Sarah Elizabeth Beauty</title>
</head>
<body>
        <?php
        if(isset($_POST['nome'])){

            if(isset($_GET['id_up']) && !empty($_GET['id_up'])){
                $id_upd = addslashes($_GET['id_up']);
                $nome = addslashes($_POST['nome']);
                $email= addslashes($_POST['email']);
                $imagem= addslashes($_POST['imagem']);
                if(!empty($nome) && !empty($email) && !empty($imagem)){
                    $p->atualizarDados($id_upd, $nome, $email, $imagem);
                    header("location: fotos.php");
                }   
            }else{
                $nome = addslashes($_POST['nome']);
                $email= addslashes($_POST['email']);
                $imagem= addslashes($_POST['imagem']);
                if(!empty($nome) && !empty($email) && !empty($imagem)){
                    if(!$p->cadastrarDados($nome, $email, $imagem)){
                    }
                }else{   
                    echo "Preencha todos os campos";
                }
            }
        }

        ?>

        <?php
        if(isset($_GET['id_up'])){
            $id_update = addslashes($_GET['id_up']);
            $res = $p->buscarDadosEditar($id_update);
        }
        
        ?>
        <form class="login-box" method="POST">
            <h2 class="titulo">CADASTRO</h2>
            
            <div class="input-container">
                <input type="text" name="nome" value="<?php if(isset($res)){echo $res['Nome'];}  ?>" >
            </div>
            
            <div class="input-container">
                <input type="text" name="email" value="<?php if(isset($res)){echo $res['Email'];}  ?>">
            </div>

            <div class="input-container">
                <input type="file" name="imagem" value="<?php if(isset($res)){echo $res['Imagem'];}  ?>" >
            </div>

            <button type="submit" class="login-button" value=""><?php 
            if(isset($res)){
                echo "Atualizar";
                }else{
                    echo "Cadastrar";}   ?></button>
        </form>

        <a href="../views/login.php" class="link-cadastro">Já possui cadastro? <span class="destaque">Clique aqui!</span></a>

        <?php
            $dados = $p->buscarDados();
            if(count($dados) > 0){
                for ($i=0; $i < count($dados); $i++){
                    echo "<p> ";
                    foreach ($dados[$i] as $k => $v){
                        if($k != "id"){
                            echo " <b>".$v."</b> ";
                        }
                    }
                    ?>
                    <a href="fotos.php?id=<?php echo $dados[$i]['id']; ?>">Excluir</a> 
                    <a href="fotos.php?id_up=<?php echo $dados[$i]['id']; ?>">Editar</a>
                    <?php
                    echo "</p> ";
                }
            } else{
                echo "Ainda não há imagem cadastrada";
            }
            
        ?>

</body>
</html>

<?php
    if(isset($_GET['id'])){
        $id_img = addslashes($_GET['id']);
        $p->excluirDados($id_img);
        header("location: fotos.php");
    }
?>