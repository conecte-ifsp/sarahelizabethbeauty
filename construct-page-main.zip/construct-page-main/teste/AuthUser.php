<?php

Class Imagem{

    private $pdo;

    public function __construct($dbname, $host, $user, $senha){
        try{
            $this->pdo = new PDO("mysql:dbname=".$dbname.";host=".$host,$user,$senha);
        }   
        catch (PDOException $e){
            echo "Erro com banco de dados: ".$e->getMessage();
            exit();
        }
        catch (Exception $e){
            echo "Erro generico: ".$e->getMessage();
            exit();
        }
    }

    public function buscarDados(){
        $res = array();
        $cmd = $this->pdo->query("SELECT * FROM imagem ORDER BY nome");
        $res = $cmd->fetchAll(PDO::FETCH_ASSOC);
        return $res;
    }

    public function cadastrarDados($nome, $email, $imagem){
        $cmd = $this->pdo->prepare("SELECT id from imagem WHERE nome = :n");
        $cmd->bindValue(":n", $nome);
        $cmd->execute();
        if($cmd->rowCount() > 0){
            return false;
        } else {
            $cmd = $this->pdo->prepare("INSERT INTO imagem (nome, email, imagem) VALUES (:n, :e, :i)");
            $cmd->bindValue(":n", $nome);
            $cmd->bindValue(":e", $email);
            $cmd->bindValue(":i", $imagem);
            $cmd->execute();
            return true;
        }
    } 

        public function excluirDados($id){
            $cmd = $this->pdo->prepare("DELETE FROM imagem WHERE id = :id");
            $cmd->bindValue(":id",$id);
            $cmd->execute();
        }

public function buscarDadosEditar($id){
    $res = array();
    $cmd = $this->pdo->prepare("SELECT * FROM imagem WHERE id = :id");
    $cmd->bindValue(":id", $id);
    $cmd->execute();
    $res = $cmd->fetch(PDO::FETCH_ASSOC);
    return $res;
}

public function atualizarDados($id, $nome, $email, $imagem){
    
    $cmd = $this->pdo->prepare("UPDATE imagem SET nome= :n, email = :e, imagem = :i WHERE id =:id");
    $cmd->bindValue(":n" ,$nome);
    $cmd->bindValue(":e" ,$email);
    $cmd->bindValue(":i" ,$imagem);
    $cmd->bindValue(":id",$id);
    $cmd->execute();
    return true;
    }
} 

?>